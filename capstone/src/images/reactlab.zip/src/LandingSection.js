import React from 'react';
import { VStack, Image, Heading, Text } from '@chakra-ui/react';

const LandingSection = () => {
  const avatar = 'https://i.pravatar.cc/150?img=7';
  const greeting = 'Hello, I am Pete!';
  const bio1 = 'A frontend developer';
  const bio2 = 'Creating modern, user-friendly web experiences';

  return (
    <VStack spacing={4} p={8} backgroundColor="blue.700" color="white">
      <Image src={avatar} borderRadius="full" boxSize="150px" />
      <Heading>{greeting}</Heading>
      <Text>{bio1}</Text>
      <Text>{bio2}</Text>
    </VStack>
  );
};

export default LandingSection;