import React from 'react';
import { Box, VStack, Image, Heading, Text, Link, HStack } from '@chakra-ui/react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';

const Card = ({ title, description, imageSrc, link }) => {
  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      overflow="hidden"
      boxShadow="lg"
      _hover={{ transform: 'scale(1.05)', transition: '0.3s' }}
    >
      <Image src={imageSrc} alt={title} />
      <VStack align="start" p={4} spacing={4}>
        <Heading size="md">{title}</Heading>
        <Text>{description}</Text>
        <HStack spacing={2}>
          <Link href={link} isExternal color="teal.500">
            See more
          </Link>
          <FontAwesomeIcon icon={faArrowRight} />
        </HStack>
      </VStack>
    </Box>
  );
};

export default Card;