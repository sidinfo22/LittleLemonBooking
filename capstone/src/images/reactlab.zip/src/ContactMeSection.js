import React from 'react';
import { VStack, FormControl, FormLabel, Input, Textarea, Button } from '@chakra-ui/react';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const ContactMeSection = () => {
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      type: '',
      message: '',
    },
    validationSchema: Yup.object({
      name: Yup.string().required('Required'),
      email: Yup.string().email('Invalid email address').required('Required'),
      message: Yup.string().min(25, 'Must be at least 25 characters').required('Required'),
    }),
    onSubmit: (values) => {
      alert(JSON.stringify(values, null, 2));
    },
  });

  return (
    <VStack
      id="contactme-section"
      as="form"
      spacing={4}
      p={8}
      backgroundColor="purple.700"
      color="white"
      onSubmit={formik.handleSubmit}
    >
      <FormControl isInvalid={formik.touched.name && formik.errors.name}>
        <FormLabel>Name</FormLabel>
        <Input {...formik.getFieldProps('name')} />
      </FormControl>

      <FormControl isInvalid={formik.touched.email && formik.errors.email}>
        <FormLabel>Email</FormLabel>
        <Input {...formik.getFieldProps('email')} />
      </FormControl>

      <FormControl>
        <FormLabel>Type</FormLabel>
        <Input {...formik.getFieldProps('type')} />
      </FormControl>

      <FormControl isInvalid={formik.touched.message && formik.errors.message}>
        <FormLabel>Message</FormLabel>
        <Textarea {...formik.getFieldProps('message')} />
      </FormControl>

      <Button type="submit" colorScheme="teal">
        Submit
      </Button>
    </VStack>
  );
};

export default ContactMeSection;