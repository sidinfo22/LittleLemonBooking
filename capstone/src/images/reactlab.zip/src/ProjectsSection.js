import React from 'react';
import { VStack, Heading, SimpleGrid } from '@chakra-ui/react';
import Card from './Card'; // Create this component inside the same folder

const projects = [
  { title: 'React Space', description: 'Amazing AR components', image: 'image1.png' },
  { title: 'Photo Gallery', description: 'A shop for photographers', image: 'image2.png' },
  { title: 'Event Planner', description: 'Plan your events with ease', image: 'image3.png' },
];

const ProjectsSection = () => {
  return (
    <VStack id="projects-section" spacing={8} p={8} backgroundColor="green.700" color="white">
      <Heading>Featured Projects</Heading>
      <SimpleGrid columns={[1, 2, 3]} spacing={8}>
        {projects.map((project, index) => (
          <Card key={index} {...project} />
        ))}
      </SimpleGrid>
    </VStack>
  );
};

export default ProjectsSection;