import React, { useEffect, useRef, useState } from 'react';
import { Box, HStack, Link } from '@chakra-ui/react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const socials = [
  { icon: ['fab', 'twitter'], href: 'https://twitter.com' },
  { icon: ['fab', 'facebook'], href: 'https://facebook.com' },
  { icon: ['fab', 'linkedin'], href: 'https://linkedin.com' },
];

const Header = () => {
  const [isVisible, setIsVisible] = useState(true);
  const lastScrollY = useRef(0);

  const handleScroll = () => {
    const currentScrollY = window.scrollY;
    if (currentScrollY > lastScrollY.current) {
      setIsVisible(false); // Hide header when scrolling down
    } else {
      setIsVisible(true); // Show header when scrolling up
    }
    lastScrollY.current = currentScrollY;
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Box
      as="header"
      transform={isVisible ? 'translateY(0)' : 'translateY(-200px)'}
      transition="transform 0.3s ease-in-out"
      backgroundColor="black"
      color="white"
      position="fixed"
      top={0}
      width="100%"
      zIndex="1000"
    >
      <HStack as="nav" spacing={8} p={4} justify="space-between">
        <HStack spacing={4}>
          {socials.map((social, index) => (
            <Link key={index} href={social.href} isExternal>
              <FontAwesomeIcon icon={social.icon} size="2x" />
            </Link>
          ))}
        </HStack>
        <HStack spacing={4}>
          <Link href="/#projects-section">Projects</Link>
          <Link href="/#contactme-section">Contact Me</Link>
        </HStack>
      </HStack>
    </Box>
  );
};

export default Header;